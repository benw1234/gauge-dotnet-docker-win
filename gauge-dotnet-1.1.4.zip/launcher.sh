#! /bin/sh

dotnet bin/Gauge.Dotnet.dll $@
